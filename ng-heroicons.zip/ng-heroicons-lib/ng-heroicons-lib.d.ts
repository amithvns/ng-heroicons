/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ng-heroicons-lib" />
export * from './public-api';
