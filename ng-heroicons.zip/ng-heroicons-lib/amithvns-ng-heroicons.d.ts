/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@amithvns/ng-heroicons" />
export * from './public-api';
