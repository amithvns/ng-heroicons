import { InjectionToken } from '@angular/core';
export declare const ICON_SET_TOKEN: InjectionToken<unknown>;
