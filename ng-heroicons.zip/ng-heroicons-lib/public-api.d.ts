export * from './lib/icons-outline';
export * from './lib/icons-solid';
export * from './lib/icon/icon.component';
export * from './lib/icons.module';
